<?php
/**
 * base request class
 * @author zengfanwei
 */
namespace frame\base;


class Request
{
    public $buf;
    public $data;
    public $servType;
    public $server;
}