<?php

class BaseTimer extends frame\core\Runnable {
    /**
     * [run 执行函数]
     * @return [type] [description]
     */
    public function run($subTaskId)
    {
		
    }
}