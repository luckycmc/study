<?php

/**
 * Created by PhpStorm.
 * User: zengfanwei
 * Date: 2017/6/28
 * Time: 15:21
 */
class AjaxController extends \frame\base\Controller
{
    public function addUerPlayDetail()
    {

    }
}