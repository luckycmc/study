<?php


class testProtocol extends \frame\base\Protocol
{

}